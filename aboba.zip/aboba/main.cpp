#include <iostream>
#include <fstream>
#include <string>

using namespace std;
/*
 * Struktura: drzewo
 * Opis: Reprezentuje pojedynczy wezel binarnego drzewa poszukiwan (BST).
 * Pola:
 *   liczba - wartosc calkowita przechowywana w wezle
 *   lewy   - wskaznik na lewe poddrzewo (wartosci mniejsze lub rowne)
 *   prawy  - wskaznik na prawe poddrzewo (wartosci wieksze)
 */
struct drzewo
{
    int liczba;
    drzewo* lewy;
    drzewo* prawy;
};
// Licznik globalny zliczajacy liczbe wykonanych operacji delete
int licznik_delete = 0;

/*
 * Nazwa funkcji: wstaw
 * Opis: Rekurencyjnie wstawia nowa liczbe do drzewa BST oraz wypisuje
 *       sciezke przejscia po wezlach.
 * Parametry:
 *   korzen  - referencja do wskaznika na biezacy wezel drzewa
 *   liczba  - wstawiana wartosc calkowita
 *   sciezka - tekstowy opis przebytej drogi w drzewie
 * Zwracany typ: void
 */
void wstaw(drzewo* &korzen, int liczba, const string& sciezka = "korzen")
{
    if (korzen == nullptr)
    {
        drzewo* nowy = new drzewo;
        nowy->liczba = liczba;
        nowy->lewy = nullptr;
        nowy->prawy = nullptr;
        korzen = nowy;

        if (sciezka == "korzen")
        {
            cout << "Wstawiam " << liczba << " jako korzen drzewa." << endl;
        } else
        {
            cout << "Wstawiam " << liczba << " (" << sciezka << ")." << endl;
        }
        return;
    }

    if (liczba > korzen->liczba)
    {
        cout << "  " << liczba << " > " << korzen->liczba << " -> w PRAWO" << endl;
        wstaw(korzen->prawy, liczba, sciezka + " -> P");
    } else
    {
        cout << "  " << liczba << " <= " << korzen->liczba << " -> w LEWO" << endl;
        wstaw(korzen->lewy, liczba, sciezka + " -> L");
    }
}

/*
 * Nazwa funkcji: rysuj_z_gory
 * Opis: Wyswietla strukture drzewa od korzenia w dol z uzyciem wciec
 *       i lacznikow galezi.
 * Parametry:
 *   korzen  - wskaznik na biezacy wezel drzewa
 *   prefiks - ciag znakow budujacy wciecia i linie galezi
 *   ostatni - informacja, czy wezel jest ostatnim dzieckiem na danym poziomie
 *   strona  - oznaczenie roli wezla ("Korzen", "L", "P")
 * Zwracany typ: void
 */
void rysuj_z_gory(drzewo* korzen, const string& prefiks = "", bool ostatni = true, const string& strona = "Korzen") {
    if (korzen == nullptr)
    {
        return;
    }

    cout << prefiks;
    if (strona == "Korzen")
    {
        cout << "Korzen: " << korzen->liczba << endl;
    } else
    {
        cout << (ostatni ? "`-- " : "|-- ") << strona << ": " << korzen->liczba << endl;
    }

    string nowy_prefiks = prefiks;
    if (strona != "Korzen")
    {
        nowy_prefiks += (ostatni? "    " : "|   ");
    }

    bool ma_lewy = (korzen->lewy != nullptr);
    bool ma_prawy = (korzen->prawy != nullptr);

    if (ma_lewy)
    {
        rysuj_z_gory(korzen->lewy, nowy_prefiks, !ma_prawy, "L");
    }
    if (ma_prawy)
    {
        rysuj_z_gory(korzen->prawy, nowy_prefiks, true, "P");
    }
}

/*
 * Nazwa funkcji: wypisz
 * Opis: Przechodzi drzewo w porzadku in-order (lewe -> korzen -> prawe),
 *       co wypisuje liczby w kolejnosci rosnacej.
 * Parametry:
 *   korzen - wskaznik na biezacy wezel drzewa
 * Zwracany typ: void
 */
void wypisz(drzewo* korzen)
{
    if (korzen == nullptr)
    {
        return;
    }

    wypisz(korzen->lewy);
    cout << korzen->liczba << " ";
    wypisz(korzen->prawy);
}

/*
 * Nazwa funkcji: usun_drzewo
 * Opis: Rekurencyjnie zwalnia pamiec zajmowana przez wszystkie wezly drzewa
 *       w porzadku post-order i inkrementuje globalny licznik operacji delete.
 * Parametry:
 *   korzen - referencja do wskaznika na biezacy wezel drzewa
 * Zwracany typ: void
 */
void usun_drzewo(drzewo* &korzen)
{
    if (korzen == nullptr)
    {
        return;
    }
    usun_drzewo(korzen->lewy);
    usun_drzewo(korzen->prawy);
    delete korzen;
    korzen = nullptr;
    licznik_delete++;
}

/*
 * Nazwa funkcji: main
 * Opis: Glowna funkcja programu. Wczytuje liczby z pliku dane.txt, buduje
 *       drzewo BST, rysuje jego schemat, wypisuje posortowane liczby oraz
 *       zwalnia pamiec, weryfikujac liczbe usunietych rekordow.
 * Zwracany typ: int - kod zakonczenia programu (0 - sukces, 1 - blad pliku)
 */
int main()
{
    drzewo* d = nullptr;
    ifstream plik("dane.txt");
    if (!plik.is_open())
    {
        cerr << "Blad: nie udalo sie otworzyc pliku dane.txt" << endl;
        return 1;
    }

    int liczba;
    int wczytane_rekordy = 0;

    cout << "--- Budowanie drzewa krok po kroku ---" << endl;
    while (plik >> liczba) {
        wstaw(d, liczba);
        wczytane_rekordy++;
    }
    plik.close();

    cout << endl;
    cout << "--- Schemat drzewa ---" << endl;
    rysuj_z_gory(d);

    cout << endl;
    cout << "Posortowane liczby: ";
    wypisz(d);
    cout << endl;

    usun_drzewo(d);
    cout <<endl;
    cout <<"Usunieto: " << licznik_delete << " rekordow z pamieci." << endl;

    if (licznik_delete == wczytane_rekordy)
    {
        cout<< "Zgadza sie z liczba wczytanych liczb z pliku (" << wczytane_rekordy << ")." << endl;
    } else
    {
        cout<< "Niezgodnosc: wczytano " << wczytane_rekordy<< ", usunieto " << licznik_delete << "." << endl;
    }

    return 0;
}
